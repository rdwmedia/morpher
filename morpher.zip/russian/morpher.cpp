﻿#include "morpher.h"

const tstring Common::vowels = _T("аяоёиыуюэе");
